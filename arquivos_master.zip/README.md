# Git e GitHub: Do Básico ao Avançado c/ Gist e GitHub Pages

Este repositório contém anotações, exemplos e exercícios feitos durante o curso **"Git e GitHub: Do Básico ao Avançado c/ Gist e GitHub Pages"**.

📌 **Observação:** Este repositório é apenas para fins de estudo e prática pessoal.

